package request

type UserLoginRequest struct {
	Username string `json:"username" binding:"required" chinese:"用户名"`
	Password string `json:"password" binding:"required" chinese:"密码"`
}

type UserRegisterRequest struct {
	ID       uint64 `json:"id" binding:"gte=0" chinese:"用户Id"`
	Username string `json:"username" binding:"required,min=3,max=20" chinese:"用户名"`
	Password string `json:"password" binding:"required,min=6,max=20" chinese:"密码"`
	NickName string `json:"nickname" binding:"" chinese:"昵称"`
	Email    string `json:"email" binding:"required,email" chinese:"邮箱"`
	Phone    string `json:"phone" binding:"required,len=11" chinese:"手机号"`
	Avatar   string `json:"avatar" binding:"" chinese:"头像"`
	RoleId   uint64 `json:"roleId" binding:"required,gte=1" chinese:"角色Id"` // 添加角色 ID 字段
}

type UserListRequest struct {
	Page     int    `json:"page" binding:"required,gt=0" chinese:"页码"`
	PageSize int    `json:"pageSize" binding:"required,gt=0" chinese:"每页数量"`
	Username string `json:"username" binding:"min=3,max=20" chinese:"用户名"`
	NickName string `json:"nickname" binding:"" chinese:"昵称"`
	Status   int    `json:"status" binding:"gt=0,lte=2" chinese:"状态"`
	RoleId   uint64 `json:"roleId" binding:"gte=0" chinese:"角色Id"`
}

type UserUpdateRequest struct {
	UserID   uint64 `json:"userId" binding:"required"`
	Username string `json:"username"`
	Email    string `json:"email"`
	// 可以添加其他需要更新的字段
}
