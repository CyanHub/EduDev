package config

type App struct {
	Port int `json:"port"`
}
